import csv
import pprint
from PIL import Image, ImageChops
from pathlib import Path
import mstr
import json
fldr_r = mstr.root[:-1] + '_!/r'
fldr_g = mstr.root[:-1] + '_!/g'
fldr_b = mstr.root[:-1] + '_!/b'
fldr_a = mstr.root[:-1] + '_!/alpha'
mstr.copyDirectory(mstr.root, fldr_a)
mstr.copyDirectory(mstr.root, fldr_r)
mstr.copyDirectory(mstr.root, fldr_g)
mstr.copyDirectory(mstr.root, fldr_b)
tally = {}

for f in mstr.images:
    #   Creates Alpha Channel Image and RGB
    print(f)
    try:
        image_path = mstr.root + f.replace('.png', '.dds')
        mask_path_A = mstr.root[:-1] + '_!/alpha/' + f.replace('.dds', '.png')
        mask_path_R = mstr.root[:-1] + '_!/r/' + f.replace('.dds', '.png')
        mask_path_G = mstr.root[:-1] + '_!/g/' + f.replace('.dds', '.png')
        mask_path_B = mstr.root[:-1] + '_!/b/' + f.replace('.dds', '.png')
        image = Image.open(image_path)
        image.getchannel('R').save(mask_path_R)
        image.getchannel('G').save(mask_path_G)
        image.getchannel('B').save(mask_path_B)
        alpha = image.getchannel('A')
        if not ImageChops.invert(alpha).getbbox():
            tally[f] = 'RGB'
            pass
        else:
            alpha.save(mask_path_A)
            tally[f] = 'RGBA'
        # except FileNotFoundError:
        #     print('You forgot to run DIRECTORY CREATOR first. Probably')
    except NotImplementedError:
        print(f'{f} could not be copied. Probably a glow map. Safe to ignore these usually...')
        tally[f] = 'Ignored'
tally_rgba = [x for x in tally if tally[x] == 'RGBA']
tally_rgb = [x for x in tally if tally[x] == 'RGB']
tally_ignored = [x for x in tally if tally[x] == 'Ignored']
pprint.pprint( 'Once files are split DO NOT MOVE FROM FOLDERS OR RENAME, DO NOT REMOVE ORIGINAL DDS FILES! The REJOINER will NOT be able to find them. MODIFYING THE FILES IS OK. MAKING COPIES AND BACK UPS IS OK AND RECOMMENDED.', width= 100)
pprint.pprint(f'Of {len(mstr.images)} processed. {len(tally_rgba)} were RGBA. {len(tally_rgb)} were RGB. {len(tally_ignored)} were ignored. {len(tally_rgba)*6 + len(tally_rgb)*3} files were created. ')
with open('master_image_list_4c.txt', 'w') as outfile:
    json.dump(mstr.images, outfile)
with open('images_split_dictionary_4c.txt', 'w', newline='') as csv_file:
    writer = csv.writer(csv_file, skipinitialspace=False)
    for key, value in tally.items():
        writer.writerow([key, value])
