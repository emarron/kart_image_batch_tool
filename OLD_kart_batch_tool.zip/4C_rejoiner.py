import csv
import json
from PIL import Image, ImageOps
from pathlib import Path
import mstr

tally = {}
fldr_cmpst_4c = mstr.root[:-1] + '_!/composite_4c'
fldr_cmpst_3c = mstr.root[:-1] + '_!/composite_3c'
mstr.copyDirectory(mstr.root, fldr_cmpst_4c)
mstr.copyDirectory(mstr.root, fldr_cmpst_3c)
with open('master_image_list_4c.txt', 'r') as infile:
    image_lst = json.load(infile)

for f in image_lst:
    #   marries alpha and RGB channels as png, must match folder structure of original split from 'RGBA_SPLITTER.py'
    print(f)
    image_path = mstr.root + f
    mask_path_A = mstr.root[:-1] + '_!/alpha/' + f.replace('.dds', '.png')
    mask_path_R = mstr.root[:-1] + '_!/r/' + f.replace('.dds', '.png')
    mask_path_G = mstr.root[:-1] + '_!/g/' + f.replace('.dds', '.png')
    mask_path_B = mstr.root[:-1] + '_!/b/' + f.replace('.dds', '.png')
    cmpst_path_4c = mstr.root[:-1] + '_!/composite_4c/' + f.replace('.dds', '.tga')
    cmpst_path_3c = mstr.root[:-1] + '_!/composite_3c/' + f.replace('.dds', '.png')
    try:
        alpha = Image.open(mask_path_A)
        galpha = ImageOps.grayscale(alpha)
        r = Image.open(mask_path_R).convert('L')
        g = Image.open(mask_path_G).convert('L')
        b = Image.open(mask_path_B).convert('L')
        bg = Image.merge('RGBA',(r,g,b,galpha))
        try:
            # print('{:s} is RGBA, saving to 4c as TGA.')
            bg.save(cmpst_path_4c)
        except FileExistsError:
            pass
            # print('{:s} already exists. Skipping.')
        tally[f] = 'RGBA'

    except FileNotFoundError:
        try:
            r = Image.open(mask_path_R).convert('L')
            g = Image.open(mask_path_G).convert('L')
            b = Image.open(mask_path_B).convert('L')
            try:
                # print('{:s} is RGB, saving to 3c as png.')
                bg = Image.merge('RGB',(r,g,b))
                bg.save(cmpst_path_3c)
            except FileExistsError:
                pass
                # print(f'{cmpst_path_3c} already exists. Skipping.')
            tally[f] = 'RGB'
        except FileNotFoundError:
            print(f'You probably changed or lost this file {cmpst_path_4c}. Make Sure you put it in the right place and try again!')
tally_rgba = [x for x in tally if tally[x] == 'RGBA']
tally_rgb = [x for x in tally if tally[x] == 'RGB']
tally_ignored = [x for x in tally if tally[x] == 'Ignored']
lst_m = tally_rgba + tally_rgb
print(f'Process complete. {len(tally_rgb)+len(tally_rgba)*2} files read. {len(tally_rgb)} rgb images as png files. {len(tally_rgba)} rgba images as tga files.')

with open('images_rejoined_dictionary_4c.txt', 'w',newline='') as csv_file:
    writer = csv.writer(csv_file, skipinitialspace=False)
    for key, value in tally.items():
        writer.writerow([key, value])

with open('images_split_dictionary_4c.txt', 'r',newline='') as split_file:
    reader = csv.reader(split_file, skipinitialspace=False)
    split_dic = {rows[0]:rows[1] for rows in reader}

shared_items = {k: tally[k] for k in tally if k in split_dic and tally[k] == split_dic[k]}
print(f'Of {len(split_dic)} originally split, {len(shared_items)} of these were merged back together.')