
<p><a href="https://www.youtube.com/watch?v=VkIgHGogzHM&amp;feature=youtu.be">https://www.youtube.com/watch?v=VkIgHGogzHM&amp;feature=youtu.be</a></p>
<h1><a id="kart_batch_tool_0"></a>kart_batch_tool</h1>
<p>general purpose:<br>
to sort and convert dds images for image manipulation via esrgan or topaz ai or whatever.<br>
list of module:<br>
mstr.py<br>
  where master functions are stored.<br>
  change:<br>
  root = ./example/<br>
  to whatever master folder you are using.<br>
  i.e<br>
  Trying to do the whole textures folder in one go because you’re stupid. Please don’t.<br>
  root = ./textures/<br>
  The clothing folder.<br>
  root = ./clothing/<br>
  You copied the whole texture folder, but you only want to change argonian character<br>
  textures for some reason.<br>
  root = ‘./textures/characters/argonian/’<br>
sorter.py<br>
  Reads root from master file.<br>
  Copies dds files from master and sorts them according to whether they are normal (<em>n), glow (<em>g), or diffuse.<br>
  creates:<br>
  root_normal/*<br>
  root_glow/*<br>
  root_diffuse/*<br>
 rgba_splitter.py<br>
  reads root from master file.<br>
  splits dds files into alpha and rgb. Stores as png in respective folders.<br>
  creates:<br>
  root_%/alpha/*<br>
  root_%/RGB/*<br>
  master_image_list.txt<br>
  images_split_dictionary.txt<br>
rgba_rejoiner.py<br>
  reads from ‘master_image_list.txt’ and root from master file.<br>
  merges split alpha and rgb. Stores as tga when RGBA.<br>
  creates:<br>
  root_%/composite_4c/*<br>
  root_%/composite_3c/*<br>
4C_splitter.py<br>
  reads root from master file.<br>
  splits dds files into r, g, b, and alpha. Stores as png in respective folders.<br>
  creates:<br>
  root_!/a/*<br>
  root_!/r/*<br>
  root_!/b/*<br>
  root_!/g/*<br>
  master_image_list_4c.txt<br>
  images_split_dictionary_4c.txt<br>
4C_rejoiner<br>
  reads from ‘master_image_list_4c.txt’ and root from master file.<br>
  merges split alpha and r, g, b. Stores as tga when RGBA.<br>
  creates:<br>
  root_!/composite_4c/*<br>
  root_!/composite_3c/*</p>
