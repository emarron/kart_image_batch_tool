import shutil
from pathlib import Path

root = './characters_diffuse/'

source_dir = Path(root)



def copyDirectory(src, dest):
    # from https://www.pythoncentral.io/how-to-recursively-copy-a-directory-folder-in-python/
    try:
        iggy = shutil.ignore_patterns('*.dds', '_%')
        shutil.copytree(src, dest, ignore=iggy)
    # Directories are the same
    except shutil.Error as e:
        print('Directory not copied. Error: %s' % e)
    # Any error saying that the directory doesn't exist
    except OSError as e:
        print('Directory not copied. Error: %s' % e)

def walk_dir(dir):
    for path in dir.iterdir():
        if path.is_dir():
            yield from walk_dir(path)
        else:
            yield path

files = [str(x) for x in walk_dir(source_dir) if x.is_file()]
images = []
for x in files:
    images.append(x[len(root)-2:])