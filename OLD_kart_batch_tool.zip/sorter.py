import shutil
import mstr

#generate folders
fldr_n = mstr.root[:-1]+'_normal'
fldr_d = mstr.root[:-1]+'_diffuse'
fldr_g = mstr.root[:-1]+'_glow'
mstr.copyDirectory(mstr.root, fldr_n)
mstr.copyDirectory(mstr.root, fldr_d)
mstr.copyDirectory(mstr.root, fldr_g)

for f in mstr.images:
    image_path = mstr.root + f
    mask_path_n = fldr_n + '/' + f
    mask_path_d = fldr_d + '/' + f
    mask_path_g = fldr_g + '/' + f
    if '_n' in f:
        shutil.copy(image_path, mask_path_n)
    elif '_g' in f:
        shutil.copy(image_path, mask_path_g)
    else:
        shutil.copy(image_path, mask_path_d)
