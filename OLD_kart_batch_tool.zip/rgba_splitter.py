import csv
import pprint
from PIL import Image, ImageChops
from pathlib import Path
import mstr
import json
fldr_rgb = mstr.root[:-1] + '_%/rgb'
fldr_a = mstr.root[:-1] + '_%/alpha'
mstr.copyDirectory(mstr.root, fldr_a)
mstr.copyDirectory(mstr.root, fldr_rgb)
tally = {}

for f in mstr.images:
    #   Creates Alpha Channel Image and RGB
    print(f)
    try:
        image_path = mstr.root + f.replace('.png', '.dds')
        mask_path_A = mstr.root[:-1] + '_%/alpha/' + f.replace('.dds', '.png')
        mask_path_RGB = mstr.root[:-1] + '_%/rgb/' + f.replace('.dds', '.png')
        image = Image.open(image_path)
        image.convert('RGB').save(mask_path_RGB)
        alpha = image.getchannel('A')
        if not ImageChops.invert(alpha).getbbox():
            tally[f] = 'RGB'
            pass
        else:
            alpha.save(mask_path_A)
            tally[f] = 'RGBA'
        # except FileNotFoundError:
        #     print('You forgot to run DIRECTORY CREATOR first. Probably')
    except NotImplementedError:
        print(f'{f} could not be copied. Probably a glow map. Safe to ignore these usually...')
        tally[f] = 'Ignored'
tally_rgba = [x for x in tally if tally[x] == 'RGBA']
tally_rgb = [x for x in tally if tally[x] == 'RGB']
tally_ignored = [x for x in tally if tally[x] == 'Ignored']
pprint.pprint( 'Once files are split DO NOT MOVE FROM FOLDERS OR RENAME, DO NOT REMOVE ORIGINAL DDS FILES! The REJOINER will NOT be able to find them. MODIFYING THE FILES IS OK. MAKING COPIES AND BACK UPS IS OK AND RECOMMENDED.', width= 100)
pprint.pprint(f'Of {len(mstr.images)} processed. {len(tally_rgba)} were RGBA. {len(tally_rgb)} were RGB. {len(tally_ignored)} were ignored. {len(tally_rgba)*2 + len(tally_rgb)} files were created. ')
with open('master_image_list.txt', 'w') as outfile:
    json.dump(mstr.images, outfile)
with open('images_split_dictionary.txt', 'w', newline='') as csv_file:
    writer = csv.writer(csv_file, skipinitialspace=False)
    for key, value in tally.items():
        writer.writerow([key, value])
