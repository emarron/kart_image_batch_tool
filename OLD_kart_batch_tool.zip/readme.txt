general purpose:
to sort and convert dds images for image manipulation via esrgan or topaz ai or whatever.
list of module:
mstr.py
	where master functions are stored.
    change:
    root = './example/'
    to whatever master folder you are using.
    i.e
    Trying to do the whole textures folder in one go because you're stupid. Please don't.
    root = './textures/'
    The clothing folder.
    root = './clothing/'
    You copied the whole texture folder, but you only want to change argonian character
    textures for some reason.
    root = './textures/characters/argonian/'
sorter.py
	Reads root from master file.
	Copies dds files from master and sorts them according to whether they are normal (_n), glow (_g), or diffuse.
	creates:
	root_normal/*
	root_glow/*
	root_diffuse/*
rgba_splitter.py
	reads root from master file.
	splits dds files into alpha and rgb. Stores as png in respective folders.
	creates:
	root_%/alpha/*
	root_%/RGB/*
	master_image_list.txt
	images_split_dictionary.txt
rgba_rejoiner.py
	reads from 'master_image_list.txt' and root from master file.
	merges split alpha and rgb. Stores as tga when RGBA.
	creates:
	root_%/composite_4c/*
	root_%/composite_3c/*
4C_splitter.py
	reads root from master file.
	splits dds files into r, g, b, and alpha. Stores as png in respective folders.
	creates:
	root_!/a/*
	root_!/r/*
	root_!/b/*
	root_!/g/*
	master_image_list_4c.txt
	images_split_dictionary_4c.txt
4C_rejoiner
	reads from 'master_image_list_4c.txt' and root from master file.
	merges split alpha and r, g, b. Stores as tga when RGBA.
	creates:
	root_!/composite_4c/*
	root_!/composite_3c/*
